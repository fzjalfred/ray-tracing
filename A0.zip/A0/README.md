# Compilation
First, run
```asm
premake4 gmake
make
```
in root folder.

Second, run
```asm
premake4 gmake
make
```
in A0 folder.

Third, boot ``` ./A0 ```

# Manual
No any change made in header file.

add Q, R shortcuts and buttons for quit and reset.

add r,g,b sliders for color setting.

add +/- keys for resizing.

add rotation slider allowing 360 degree maximum.