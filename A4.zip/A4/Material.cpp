// Termm--Fall 2022

#include "Material.hpp"

Material::Material()
{}

Material::~Material()
{}
