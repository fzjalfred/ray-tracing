// Termm--Fall 2022

#pragma once

#include <string>

bool run_lua( const std::string& filename );
