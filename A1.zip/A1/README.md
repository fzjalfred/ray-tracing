# Compilation
In A1 folder,
```
premake4 gmake
make
```
boot ``` ./A1 ```

# Manual
Follow assignment specifications.

new added files:
Cube.hpp
Sphere.hpp