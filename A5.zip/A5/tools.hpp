#include <glm/glm.hpp>


glm::vec3 randomInUnitSphere();